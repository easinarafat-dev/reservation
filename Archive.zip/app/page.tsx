import ReservationForm from "./_components/ReservationForm";

export default function Home() {
  return <ReservationForm />;
}
